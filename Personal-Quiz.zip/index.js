var readlineSync = require('readline-sync');
var chalk = require('chalk');

var score = 0;
var combo = 1;

var highOne ={
  name : "Pratham",
  score : 298
}
var highTwo={
  name : "Jack",
  score : 248
}
var highThree={
  name : "Cain",
  score : 246
}

var highScorers = [highOne, highTwo, highThree];

function printHighs(){
  for(z=0;z<highScorers.length;z++){
    console.log(chalk.bgWhite.yellow.bold(highScorers[z].name+'\t\t\t\t'+highScorers[z].score));
  }
}

function printHighScorers(){
  console.log
}


var questionOne = {
  que : "Is my age over 25?" ,
  ans : 'NO',
}

var questionTwo = {
  que : 'Where am I from ?',
  ans : 'PATNA'
}

var questionThree = {
  que : 'What is the name of my pet ?',
  ans : 'MAX'
}

var questionFour = {
  que : 'Which is my favourite book ?',
  ans : 'SHIVA TRIOLOGY'
}

var questionFive = {
  que : 'What kind of weather do I prefer ?',
  ans : 'STORMY'
}

var questionSix = {
  que : "What's my favourite genre ?",
  ans : "MYTHOLOGY" || "PSYCHOLOGICAL THRILLER" 
}

var questionSeven = {
  que : "What would I choose Beaches or Mountains & Forests ?",
  ans : "MOUNTAINS & FORESTS"
}

var questionEight = {
  que : "What's my nickname ?",
  ans : "GOLU"
}

var questionNine = {
  que : "What's my favourite colour ?",
  ans : "TEAL"
}

var questionTen = {
  que : "What's my favourite hobby ? ",
  ans : "READING"
}

var questions = [ questionOne, questionTwo, questionThree, questionFour, questionFive, questionSix, questionSeven, questionEight, questionNine, questionTen ]

function play( question, answer){
  var userAns= readlineSync.question(chalk.bgWhite.cyan.bold(question));
 
  if(userAns.toUpperCase() === answer){
    console.log(chalk.greenBright("Correct Answer !"));
    combo = combo+1;
      if(combo >= 5){
      score = score+(5*combo);
    }else{
      score = score +(2*combo)
    }
  }else {
    console.log(chalk.redBright('Wrong Answer :('));
    score = score -2;
    combo = 1;
    console.log(chalk.redBright('Combo has been reset'));
  }
  console.log(chalk.greenBright("Current Score : "+score));
  console.log(chalk.bgGray.white('------------------------'));
}

console.log(chalk.bgWhite.bold.black("WELCOME TO HOW WELL DO YOU KNOW PRATHAM ? \n\n "))
console.log(chalk.bgBlackBright.white('-------------------------------------------------------------------------------'));

for(i=0;i<questions.length;i++){

  play(questions[i].que,questions[i].ans)
}
console.log("Thank You ! for playing, check out the High Scores : ")
console.log(chalk.bgGray.white("-----------"));
printHighs();
console.log(chalk.bgGray.white("-----------"));
console.log('Beat the high score ? Send me a screenshot of your results to get you name above !');


